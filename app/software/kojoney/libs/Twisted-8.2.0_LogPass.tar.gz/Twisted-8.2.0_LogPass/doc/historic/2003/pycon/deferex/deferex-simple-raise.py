x = 1 + 3
raise Exception("I can't go on!")
print x

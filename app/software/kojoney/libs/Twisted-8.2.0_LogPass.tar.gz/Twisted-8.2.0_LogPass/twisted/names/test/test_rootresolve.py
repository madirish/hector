
# Copyright (c) 2001-2004 Twisted Matrix Laboratories.
# See LICENSE for details.


"""
Test cases for Twisted.names' root resolver.
"""

from twisted.trial import unittest

class RootResolverTestCase(unittest.TestCase):
    pass

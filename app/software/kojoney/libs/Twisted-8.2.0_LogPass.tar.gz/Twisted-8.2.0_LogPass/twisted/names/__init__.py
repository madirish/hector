# Copyright (c) 2001-2004 Twisted Matrix Laboratories.
# See LICENSE for details.

"""Resolving Internet Names"""

from twisted.names._version import version
__version__ = version.short()

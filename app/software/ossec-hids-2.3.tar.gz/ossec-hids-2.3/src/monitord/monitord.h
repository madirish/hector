/* @(#) $Id: monitord.h,v 1.7 2009/06/24 17:06:27 dcid Exp $ */

/* Copyright (C) 2009 Trend Micro Inc.
 * All rights reserved.
 *
 * This program is a free software; you can redistribute it
 * and/or modify it under the terms of the GNU General Public
 * License (version 3) as published by the FSF - Free Software
 * Foundation
 */


#ifndef _MONITORD_H
#define _MONITORD_H

#ifndef ARGV0
   #define ARGV0 "ossec-monitord"
#endif
   
typedef struct _monitor_config
{
    short int day_wait;
    short int compress;
    short int sign;
    short int monitor_agents;
    int a_queue;

    char **agents;
}monitor_config;


/** Prototypes **/

/* Main monitord */
void Monitord();

/*manage_files */
void manage_files(int cday, int cmon, int cyear);

/* monitor_agents */
void monitor_agents();

/* Sign a log */
void OS_SignLog(char *logfile, char *logfile_old, int log_missing);

/* Compress log */
void OS_CompressLog(char *logfile);


/* Global variables */
monitor_config mond;


#endif

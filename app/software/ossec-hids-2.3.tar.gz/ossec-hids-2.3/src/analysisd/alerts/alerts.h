/* @(#) $Id: alerts.h,v 1.6 2009/06/24 17:06:22 dcid Exp $ */

/* Copyright (C) 2009 Trend Micro Inc.
 * All right reserved.
 *
 * This program is a free software; you can redistribute it
 * and/or modify it under the terms of the GNU General Public
 * License (version 3) as published by the FSF - Free Software 
 * Foundation
 */

/* Global  alert header */

#ifndef _ALERT__H

#define _ALERT__H

#include "log.h"
#include "exec.h"
#include "getloglocation.h"

#endif

/* @(#) $Id: sha1_op.h,v 1.4 2009/06/24 17:06:29 dcid Exp $ */

/* Copyright (C) 2009 Trend Micro Inc.
 * All right reserved.
 *
 * This program is a free software; you can redistribute it
 * and/or modify it under the terms of the GNU General Public
 * License (version 3) as published by the FSF - Free Software
 * Foundation
 */


#ifndef __SHA1_OP_H

#define __SHA1_OP_H


typedef char os_sha1[65];

int OS_SHA1_File(char *fname, char * output);

#endif

/* EOF */
